// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
#include "ActorFolderTreeItem.h"

/*Debug macros*/
#define DoubleToString UKismetStringLibrary::Conv_DoubleToString

#define Sleep(Frame) std::this_thread::sleep_for(std::chrono::milliseconds(Frame))

#define NewThread(Execute) std::thread([&]() {Execute}).detach()

/*Debug functions*/
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
	}
	static void FastPrint()
	{
		Print(TEXT("FastPring : Debug"));
	}
}
/*Utility*/
namespace SceneOutlinerFolderUtils
{
	FLinearColor GetOutlinerFolderDefaultColor();
	
	FName GetDefaultContextBaseMenuName();

	const FString GetFolderFullPath(const FActorFolderTreeItem* SelectedFolder);

	const FString GetFolderFullPath(const FFolder& Folder);
	
	TOptional<FLinearColor> GetFolderColor(const FString& FolderPath);
	
	void SaveFolderColors(const FString& FolderPath, TOptional<FLinearColor> FolderColor);

	void SetRowWidgetColor(TSharedPtr<SWidget> RowWidget,const FLinearColor InColor);

	TOptional<FLinearColor> GetFolderColorTemp(const FString& FolderPath);

	void SaveFolderColorsTemp(const FString& FolderPath, TOptional<FLinearColor> FolderColor);

	void ClearFolderColorsTemp();

	void TempToSave(const UWorld* World);

	void SaveMapOldName(UWorld* World);

	void OnWorldPathPostChanged(UWorld* World);

	void SavePathPreDelete(const TArray<UObject*>& Objects);

	void OnWorldDeleted();

	void UpdateFullPath(const FFolder& Source, const FFolder& Dest);

	void DeleteFullPath(const FFolder& Folder);

	void UpdateFullPathTemp(const FFolder& Source, const FFolder& Dest);

	void DeleteFullPathTemp(const FFolder& Folder);

	void SetIsTempMap(const bool IsTemp);

	const bool GetIsTempMap();

	void OLSetMapPath(const FString InMapPath);

	FString OLGetMapPath();

	void SetIsFolderMoved(const bool IsMoved);

	const bool GetIsFolderMoved();
}
